 <?php
 
namespace Otus\Classes\Lists;

use Otus\Classes\AbstractIblockPropertyValuesTable;

class ProceduresPropertyValuesTable extends AbstractIblockPropertyValuesTable
{
    public const IBLOCK_ID = 17; // Процедуры

    // Никакой связи здесь пока не нужно — только базовая таблица
}
 
 ?>