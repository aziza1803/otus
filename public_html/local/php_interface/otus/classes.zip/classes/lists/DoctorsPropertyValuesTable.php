<?php
namespace Otus\Classes\Lists;

use Bitrix\Main\Entity\Query\Join;
use Bitrix\Main\Entity\ReferenceField;
use Bitrix\Main\ORM\Fields\Relations\ManyToMany;
use Otus\Classes\AbstractIblockPropertyValuesTable;

class DoctorsPropertyValuesTable extends AbstractIblockPropertyValuesTable
{
    public const IBLOCK_ID = 16;
}

/* 
namespace Models\Lists;

use Bitrix\Main\Entity\ReferenceField;
use Models\AbstractIblockPropertyValuesTable;

class DoctorsPropertyValuesTable extends AbstractIblockPropertyValuesTable
{
    public const IBLOCK_ID = 16; // Доктора

    public static function getMap(): array
    {
        $map = [
            // PROC_IDS_MULTI — это множественное свойство, поэтому Reference будет не к ID, а к таблице значений свойств
            'PROCEDURE' => new ReferenceField(
                'PROCEDURE',
                ProceduresPropertyValuesTable::class,
                ['=this.PROC_IDS_MULTI.VALUE' => 'ref.IBLOCK_ELEMENT_ID']
            )
        ];

        return parent::getMap() + $map;
    }
}*/

 ?>